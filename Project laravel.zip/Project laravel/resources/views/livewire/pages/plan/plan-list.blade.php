<div>


    {{ $this->table }}

</div>
