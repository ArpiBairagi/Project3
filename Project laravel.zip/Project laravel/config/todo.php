<?php

return [
    'default_user_role_name' => 'User',
    'default_admin_role_name' => 'Admin'
    ];
